//
//  AppDelegate.h
//  Piratas Del Mar Caribe
//
//  Created by Sebastian  Reyes on 19/04/22.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>


@end

