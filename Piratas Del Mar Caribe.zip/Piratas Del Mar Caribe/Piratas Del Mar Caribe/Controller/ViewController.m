//
//  ViewController.m
//  Piratas Del Mar Caribe
//
//  Created by Sebastian  Reyes on 19/04/22.
//

#import "ViewController.h"
#import "TileFactory.h"
#import "Tile.h"
#import "Boss.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    TileFactory *factory = [[TileFactory alloc] init];
   self.tiles = [factory tiles];
    self.character = [factory character];
    
    self.currentPosition = CGPointMake(0, 0);
    [self updateTile];
    [self updateArrowButtons];
}

-(void) updateTile {
    
    Tile*currentTile = [[self.tiles objectAtIndex:self.currentPosition.x] objectAtIndex:self.currentPosition.y];
    [self.textViewHistory setText:currentTile.history];
    [self.backgroundImage setImage:currentTile.backgroundImage];
    
    [self.LabelHealth setText:[NSString stringWithFormat:@"%d", self.character.health]];
    [self.LabelDamage setText:[NSString stringWithFormat:@"%d", self.character.damage]];
    [self.LabelWeapon setText:self.character.weapon.name];
    [self.LabelArmor setText:self.character.armor.name];
    
    [self.buttonAction setTitle:currentTile.actionButtonTitle forState:UIControlStateNormal];
    
}

- (IBAction)actionPressed:(UIButton *)sender {
    NSLog(@"Action Pressed");
    Tile *tile = [[self.tiles objectAtIndex:self.currentPosition.x] objectAtIndex:self.currentPosition.y];
   
        
        [self updateCharacterStatsWithTile:tile];
}
   


- (IBAction)arrowPressed:(UIButton *)sender {
    int buttonTag = (int) sender.tag;
        
    switch (buttonTag) {
        case 0:
            NSLog(@"N");
            self.currentPosition = CGPointMake(self.currentPosition.x, self.currentPosition.y-1);
            break;
        case 1:
            NSLog(@"S");
            self.currentPosition = CGPointMake(self.currentPosition.x, self.currentPosition.y+1);
            break;
        case 2:
            NSLog(@"W");
            self.currentPosition = CGPointMake(self.currentPosition.x-1, self.currentPosition.y);
            break;
        case 3:
            NSLog(@"E");
            self.currentPosition = CGPointMake(self.currentPosition.x+1, self.currentPosition.y);
            break;
        default:
            NSLog(@"Ningun punto cardinal aqui");
            break;
    }

    [self updateArrowButtons];
    [self updateTile];
}

-(void) updateArrowButtons {
    
    self.buttonNorth.hidden = ![self canMoveToPoint:CGPointMake(self.currentPosition.x, self.currentPosition.y-1)];
    self.buttonSouth.hidden = ![self canMoveToPoint:CGPointMake(self.currentPosition.x, self.currentPosition.y+1)];
    self.buttonWest.hidden = ![self canMoveToPoint:CGPointMake(self.currentPosition.x-1, self.currentPosition.y) ];
    self.buttonEast.hidden = ![self canMoveToPoint:CGPointMake(self.currentPosition.x+1, self.currentPosition.y) ];
}

-(BOOL) canMoveToPoint:(CGPoint)point{
     
    if (point.x<0) { // Me paso por el W
        return NO;
    }
    if (point.y<0) { //Me paso por el N
        return NO;
    }
    if (point.x >= [self.tiles count]) { //Me paso por el E
        return NO;
    }
    if (point.y >= [[self.tiles objectAtIndex:point.x] count]) { //Me paso pro el sur
        return NO;
    }
    return YES;
}

-(void)updateCharacterStatsWithTile:(Tile*)tile {
    
    Weapon *weapon = tile.weapon;
    Armor *armor = tile.armor;
    int health = tile.healtEffect;
    
    if (weapon!=nil) {
        self.character.damage = self.character.damage - self.character.weapon.damage + weapon.damage;
        self.character.weapon = weapon;
        }
    if (armor!=nil) {
        self.character.health = self.character.health - self.character.armor.health + armor.health;
        self.character.armor = armor;
    }
    if (health!=0) {
        self.character.health = self.character.health + health;
        }
    [self updateTile];   
}
@end
