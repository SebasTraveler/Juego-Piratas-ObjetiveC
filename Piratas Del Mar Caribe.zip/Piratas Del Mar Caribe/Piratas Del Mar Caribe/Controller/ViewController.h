//
//  ViewController.h
//  Piratas Del Mar Caribe
//
//  Created by Sebastian  Reyes on 19/04/22.
//

#import <UIKit/UIKit.h>
#import "Character.h"
#import "Boss.h"

@interface ViewController : UIViewController

@property (nonatomic) CGPoint currentPosition;
@property (strong, nonatomic) NSArray * tiles;
@property (strong, nonatomic) Character *character;


@property (strong, nonatomic) IBOutlet UIImageView *backgroundImage;


@property (strong, nonatomic) IBOutlet UILabel *LabelHealth;
@property (strong, nonatomic) IBOutlet UILabel *LabelDamage;
@property (strong, nonatomic) IBOutlet UILabel *LabelWeapon;
@property (strong, nonatomic) IBOutlet UILabel *LabelArmor;

@property (strong, nonatomic) IBOutlet UITextView *textViewHistory;

@property (strong, nonatomic) IBOutlet UIButton *buttonAction;
@property (strong, nonatomic) IBOutlet UIButton *buttonNorth;
@property (strong, nonatomic) IBOutlet UIButton *buttonSouth;
@property (strong, nonatomic) IBOutlet UIButton *buttonWest;
@property (strong, nonatomic) IBOutlet UIButton *buttonEast;



- (IBAction)actionPressed:(UIButton *)sender;

- (IBAction)arrowPressed:(UIButton*)sender;


@end

