//
//  TileFactory.m
//  Piratas Del Mar Caribe
//
//  Created by Sebastian  Reyes on 19/04/22.
//

#import "TileFactory.h"
#import "Tile.h"
#import "Boss.h"

@implementation TileFactory

-(NSArray*)tiles{
    
    Tile *tile1 = [[Tile alloc] init];
    tile1.history = @"Ha llegado un mapa en una botella que parece indicar el camino a un tesoro, es una ruta peligrosa pero... ";
    tile1.backgroundImage = [UIImage imageNamed:@"Mapa.png"];
    Weapon *weapon = [[Weapon alloc] init];
    weapon.name = @"Busted Sword";
    weapon.damage = 200;
    tile1.weapon = weapon;
    
    Armor *armor = [[Armor alloc] init];
    armor.name = @"Single Cloack";
    armor.health = 150;
    tile1.armor = armor;
    
    tile1.actionButtonTitle = @"Equipate para la aventura";
    
    Tile *tile2 = [[Tile alloc] init];
    tile2.history = @"Te esta atacando la compañia de las Indias horientales. DEFIENDETE!!";
    tile2.backgroundImage = [UIImage imageNamed:@"piratasAtaque.png"];
    tile2.healtEffect = -150;
    tile2.actionButtonTitle = @"Defenderse !!";
    
    Tile *tile3 = [[Tile alloc] init];
    tile3.history = @"Tu barco esta en llamas, intenta apagar el fuego y salir pronto !!";
    tile3.backgroundImage = [UIImage imageNamed:@"PiratasBarco.png"];
    tile3.healtEffect = -100;
    tile3.actionButtonTitle = @"Apagar fuego !!";
    
    NSMutableArray *col1 = [[NSMutableArray alloc]init];
    [col1 addObject:tile1];
    [col1 addObject:tile2];
    [col1 addObject:tile3];
    
    Tile *tile4 = [[Tile alloc] init];
    tile4.history = @"Has llegado a puerto. Aqui puedes recuperarte y prepararte para seguir la aventura !!";
    tile4.backgroundImage = [UIImage imageNamed:@"PiratasPuerto.png"];
    tile4.healtEffect = 200;
    tile4.actionButtonTitle = @"Ir a la taberna";
    
    Tile *tile5 = [[Tile alloc] init];
    tile5.history = @"Has encontrado el gran herrero, te va a mejorar el armamaneto";
    tile5.backgroundImage = [UIImage imageNamed:@"PiratasHerrero.png"];
    tile5.healtEffect = 100;
    Armor *blacksmithArmor = [[Armor alloc] init];
    blacksmithArmor.name = @"Blacksmith armor";
    blacksmithArmor.health = 250;
    tile5.armor = blacksmithArmor;
    tile5.actionButtonTitle = @"Mejorar Armadura";
    
    Tile *tile6 = [[Tile alloc] init];
    tile6.history = @" CUIDADO !!  El Kraken te esta atacando. Defiende tu barco e intenta evitar que te maten !!";
    tile6.backgroundImage = [UIImage imageNamed:@"PiratasKraken.png"];
    tile6.healtEffect = -200;
    tile6 .actionButtonTitle = @"Defenderse del Kraken";

    NSMutableArray *col2 = [[NSMutableArray alloc]init];
    [col2 addObject:tile4];
    [col2 addObject:tile5];
    [col2 addObject:tile6];
    
    Tile *tile7 = [[Tile alloc] init];
    tile7.history = @"Has encontrado un loro. No para de repetir 'Dos hay, uno huesos contiene, otro monedas de oro tiene, Quieres equiparte al Loro ?";
    tile7.backgroundImage = [UIImage imageNamed:@"PiratasLoro.png"];
    
    Weapon *parrot = [[Weapon alloc] init];
    parrot.name = @"Parrot";
    parrot.damage = 300;
    tile7.weapon = parrot;
    tile7.actionButtonTitle = @"Equiparnos al loro";
    
    Tile *tile8 = [[Tile alloc] init];
    tile8.history = @"Un motin en el barco !! Demuestra tu poder para que no te hagan caminar por la tabla.";
    tile8.backgroundImage = [UIImage imageNamed:@"PiratasPasarela.png"];
    tile8.healtEffect = -80;
    tile8.actionButtonTitle = @"Defenderse !!";
    
    Tile *tile9 = [[Tile alloc] init];
    tile9.history = @"Has encontrado un Trabuco ancestral. Equipatelo para mejorar tu armamento";
    tile9.backgroundImage = [UIImage imageNamed:@"PiratasTrabuco.png"];
    
    Weapon *pistol = [[Weapon alloc] init];
    pistol.name = @"Pistol";
    pistol.damage = 350;
    tile9.weapon = pistol;
    tile9.actionButtonTitle = @"Equipar trabuco";
    
    NSMutableArray *col3 = [[NSMutableArray alloc]init];
    [col3 addObject:tile7];
    [col3 addObject:tile8];
    [col3 addObject:tile9];
    
    Tile *tile10 = [[Tile alloc] init];
    tile10.history = @"Te has topado con barbanegra, Edward Teach !!  Solo podras vencerle si has aprendido bien lo secretos del mar Caribe.";
    tile10.backgroundImage = [UIImage imageNamed:@"Piratasbarbanegra.png"];
    tile10.healtEffect = -350;
    tile10.actionButtonTitle = @"Plantar cara !!!";
    
    Tile *tile11 = [[Tile alloc] init];
    tile11.history = @"Ohh no !! Este tesoro es falso, tiene un esqueleto dentro, pero ninguna moneda :(, Quieres recoger la armadura del cadaver ?";
    tile11.backgroundImage = [UIImage imageNamed:@"PiratasTesoro2.png"];
    
    Armor *skeletonArmor =  [[Armor alloc] init];
    skeletonArmor.name = @"Skeleton Armor";
    skeletonArmor.health = 150;
    tile11.armor = skeletonArmor;
    tile11.actionButtonTitle = @"LLevarse armadura";
    
    Tile *tile12 = [[Tile alloc] init];
    tile12.history = @"Has encontrado el tesoro !!! Ahora eres un pirata rico de verdad, hora de celebrar !!";
    tile12.backgroundImage = [UIImage imageNamed:@"PiratasTesoro.png"];
    tile12.actionButtonTitle = @"A disfrutar !!";
     
    
    NSMutableArray *col4 = [[NSMutableArray alloc]init];
    [col4 addObject:tile10];
    [col4 addObject:tile11];
    [col4 addObject:tile12];
    
    NSArray *tiles = [[NSArray alloc]initWithObjects:col1,col2,col3,col4, nil];
    
    return tiles;
}

-(Character*)character {
    
    Character * character = [[Character alloc] init];
    character.name = @"cloud Strife";
    character.health = 1000;
    character.damage = 80;
    
    Weapon *weapon = [[Weapon alloc] init];
    weapon.name = @"fists";
    weapon.damage = 10;
    character.weapon = weapon;
    
    Armor *armor = [[Armor alloc] init];
    armor.name = @"old Robe";
    armor.health = 5;
    character.armor = armor;
    
    return  character ;
}

-(Boss*)boss{
    Boss*boss = [[Boss alloc] init];
    boss.health = 800;
 
    return boss;
}


@end
