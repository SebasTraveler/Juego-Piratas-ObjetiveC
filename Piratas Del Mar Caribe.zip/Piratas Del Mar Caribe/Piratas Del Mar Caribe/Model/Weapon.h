//
//  Weapon.h
//  Piratas Del Mar Caribe
//
//  Created by Sebastian  Reyes on 20/04/22.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface Weapon : NSObject

@property (strong, nonatomic) NSString * name;
@property (nonatomic) int damage;


@end

NS_ASSUME_NONNULL_END
