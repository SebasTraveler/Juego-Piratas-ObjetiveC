//
//  TileFactory.h
//  Piratas Del Mar Caribe
//
//  Created by Sebastian  Reyes on 19/04/22.
//

#import <Foundation/Foundation.h>
#import "Character.h"
#import "Boss.h"

NS_ASSUME_NONNULL_BEGIN

@interface TileFactory : NSObject

-(NSArray*)tiles;
-(Character*)character;
-(Boss*) boss;



@end

NS_ASSUME_NONNULL_END
