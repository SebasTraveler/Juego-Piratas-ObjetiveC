//
//  Character.m
//  Piratas Del Mar Caribe
//
//  Created by Sebastian  Reyes on 20/04/22.
//

#import "Character.h"

@implementation Character

@end
