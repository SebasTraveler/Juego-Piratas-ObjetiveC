//
//  Character.h
//  Piratas Del Mar Caribe
//
//  Created by Sebastian  Reyes on 20/04/22.
//

#import <Foundation/Foundation.h>
#import "Weapon.h"
#import "Armor.h"

NS_ASSUME_NONNULL_BEGIN

@interface Character : NSObject

@property (strong, nonatomic) NSString *name;
@property (strong, nonatomic) Weapon * weapon;
@property (strong, nonatomic) Armor * armor;
@property (nonatomic) int health;
@property (nonatomic) int damage;

@end

NS_ASSUME_NONNULL_END
