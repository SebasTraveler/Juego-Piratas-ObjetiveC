//
//  Boss.m
//  Piratas Del Mar Caribe
//
//  Created by Sebastian  Reyes on 21/04/22.
//

#import "Boss.h"

@implementation Boss

@end
