//
//  Tile.h
//  Piratas Del Mar Caribe
//
//  Created by Sebastian  Reyes on 19/04/22.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
#import "Weapon.h"
#import "Armor.h"
#import "Boss.h"

NS_ASSUME_NONNULL_BEGIN

@interface Tile : NSObject

@property (strong, nonatomic) NSString*history;
@property (strong, nonatomic) NSString*actionButtonTitle;
@property (strong, nonatomic) UIImage* backgroundImage; 

@property (strong, nonatomic) Weapon *weapon;
@property (strong, nonatomic) Armor *armor;
@property (nonatomic) int healtEffect;




@end

NS_ASSUME_NONNULL_END
