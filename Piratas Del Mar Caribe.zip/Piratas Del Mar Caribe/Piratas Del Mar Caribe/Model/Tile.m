//
//  Tile.m
//  Piratas Del Mar Caribe
//
//  Created by Sebastian  Reyes on 19/04/22.
//

#import "Tile.h"

@implementation Tile

@end
