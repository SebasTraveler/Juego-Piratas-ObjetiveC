//
//  Weapon.m
//  Piratas Del Mar Caribe
//
//  Created by Sebastian  Reyes on 20/04/22.
//

#import "Weapon.h"

@implementation Weapon

@end
