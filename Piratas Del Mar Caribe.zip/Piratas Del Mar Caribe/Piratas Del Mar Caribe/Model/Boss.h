//
//  Boss.h
//  Piratas Del Mar Caribe
//
//  Created by Sebastian  Reyes on 21/04/22.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface Boss : NSObject

@property (nonatomic) int health;
@property (nonatomic) int boss;


@end

NS_ASSUME_NONNULL_END
